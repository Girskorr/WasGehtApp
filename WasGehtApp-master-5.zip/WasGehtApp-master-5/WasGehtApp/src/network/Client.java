package network;

import WasGehtApp.data.Audio;
import data.Image;
import message.AudioMessage;
import message.ImageMessage;
import message.Message;
import message.TextMessage;
import user.User;


import javax.swing.*;

public class Client implements Node {

    public Client(User user) {
        clientuser = user;
    }

    private final User clientuser;
    Node server;

    @Override
    public void receive(Message message) {
        System.out.print("Nachricht: ");
        System.out.println(message.getSender().getId() + message.prettyPrint());
    }

    @Override
    public void send(Message message) {
        server.receive(message);
    }

    @Override
    public void connect(Node receiver) throws Exception {

    }


    public void connect(Client receiver) throws Exception {
        server = receiver;
    }

    public void send(TextMessage message) {
        server.receive(message);
    }

    public void send(User sender, User empfänger, Image image, String datenObjekt) {
        ImageMessage imagemessage = new ImageMessage(sender, empfänger, image, datenObjekt);
    }

    public void send(User sender, User empfänger, Audio audio) {
        AudioMessage audiomessage = new AudioMessage(sender, empfänger, audio);
        server.receiver;
        StringBuilder sb = new StringBuilder();

    }

    @Override
    public int getId() {
        return clientuser.getId();
    }

    @Override
    public User getUser() {
        return clientuser;
    }
}
