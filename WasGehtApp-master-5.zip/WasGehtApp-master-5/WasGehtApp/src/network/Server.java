package network;

import message.Message;
import user.User;

public class Server implements Node {

    public Server (int i) {
        node = new Client [i];
    }

Node[] node;

int counter = 0;

    public void receive(Message message, int id) {

    }

    @Override
    public void receive(Message message) {
        send(message);
    }

    @Override
    public void send(Message message) {
        for (Node client : node) {
            if (client.getId() == message.getRecipient().getId()) {
                client.receive(message);
                return;
            }
        }
    }

   /* public void send(Message message, int idsender, int idempfänger) {
        for (int i = 0; i < clients.length; i++) {
            if (idsender == clients[i].getId()) {
                for (int a = 0; a < clients.length; a++) {
                if (idempfänger == clients[a].getId()) {
                    clients[a].receive( message);
                }
                }
            }
        }
    }

    */

  //  public void send(Message message, int id)  {
       // nodeArray [id].send (message);

   // }

    @Override
    public void connect(Node receiver) throws ArrayIndexOutOfBoundsException {
        int counter1 = 0;
        for (int i = 0; i < node.length; i++) {
            if (node[i] != null) {
                counter1++;
            }
        }
        if (counter < node.length) {                                  //überpüft ob server noch nicht voll ist
            for (int i = 0; i < node.length; i++) {
                if (receiver.getId() == node[i].getId()) {         //überprüft die eindeutigkeit des Users
                    break;
                }
                else {
                    node[counter] = receiver;
                }
            }
        }
            else {
            throw new ArrayIndexOutOfBoundsException("Server voll");
        }
    }

    @Override
    public int getId() {
        return 0;
    }

    @Override
    public User getUser() {
        return node[0].getUser();
    }

    public int getId(int index) {
        return node[index].getId() ;
    }

    public User getUser(int id) {
        return node[id].getUser();
    }

}
