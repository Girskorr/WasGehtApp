package network;

import WasGehtApp.data.Audio;
import data.Image;
import message.AudioMessage;
import message.ImageMessage;
import message.Message;
import message.TextMessage;
import user.User;


import javax.swing.*;

public class Client implements Node {
Jlist <String>  liste= new Jlist <String>;
String a = "test";
liste.add


        public  Client (User user) {
            clientuser = user;
        }
        private final User clientuser;
        Node node;
JButton button = new JButton();
    @Override
    public void receive(Message message) {
        System.out.print("Nachricht: ");
        System.out.println (message.getSender().getId() + message.prettyPrint());
    }

    @Override
    public void send(Message message) {
        node.receive(message);
    }

    @Override
    public void connect(Node receiver) throws Exception {

    }


    public void connect(Client receiver) throws Exception {
        node = receiver;
    }

    public void send (TextMessage message) {
        node.receive(message);
    }

    public void send (User sender, User empfänger, Image image, String datenObjekt) {
        ImageMessage imagemessage = new ImageMessage(sender,empfänger, image,datenObjekt);
    }

    public void send (User sender, User empfänger, Audio audio) {
            AudioMessage audiomessage = new AudioMessage( sender,  empfänger,  audio);
            node.receiver;
        StringBuilder sb = new StringBuilder();

    }
    
    @Override
    public int getId() {
        return clientuser.getId();
    }

    @Override
    public User getUser() {
        return clientuser;
    }
}
